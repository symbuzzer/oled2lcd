For support this project: [Patreon](https://avalibeyaz.com/patreon)  
--------------

## v1.3.0
- Added 1 different variants (2.0 and 1.5) to releases
  
## v1.2.2
- Added KernelSU support    
  
## v1.2.1
- Added create&release workflow  
  
## v1.2.0  
- First version by me :)  
- Renamed saturation to oled2lcd  
- Changed versioning structure from vx.y to vx.y.z
- Added update feature  
- Addded changelog  
  
## v1.1  
- This release is from original module developer, Draco. So there is no any notes about changes  
  
## v1.0  
- This version also created by original developer, Draco. Probably it was initial release  
